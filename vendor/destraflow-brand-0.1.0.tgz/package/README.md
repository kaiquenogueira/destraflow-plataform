# @destraflow/brand — fundação de marca

Fonte única da identidade da plataforma **Destraflow Tech** ([ADR-0098](../../docs/adr/0098-a-plataforma-se-chama-destraflow-tech.md),
que emenda o ADR-0022 tirando esta propriedade de `packages/ui`). Contrato visual completo:
[docs/design/destraflow-tech.md](../../docs/design/destraflow-tech.md).

- `src/tokens.css` — **única** fonte de cor, tipografia, espaço, raio, sombra e motion.
  Temas claro/escuro por `[data-theme]`. Medida por `node scripts/check-ui-contrast.mjs` (72 pares AA).
- `src/tokens.ts` — a **única cópia autorizada** da paleta clara, para o e-mail transacional,
  que não resolve CSS do app. `src/tokens.test.ts` trava a deriva campo a campo, nos dois sentidos.
- `src/index.ts` — `platformBrand`: nome público e endereços institucionais.
- `assets/symbol.svg` — o símbolo D, em `currentColor`.

**Este pacote é folha por desenho.** Ele não importa React, backend nem o domínio de viagens, e
a fronteira é verificada pelo `dependency-cruiser` (`brand-nao-importa-nada-do-repo`). É isso que
permite que e-mail, `manifest.json`, ícone e um consumidor fora deste repositório dependam da
mesma marca sem arrastar a árvore de componentes.

Precisa de um dado do domínio para decidir uma cor? Então não é marca — passe por props.
