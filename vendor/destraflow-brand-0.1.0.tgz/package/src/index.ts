/*
 * Fundação de marca da plataforma (ADR-0098).
 *
 * Este pacote é a ÚNICA fonte de nome público, endereços institucionais e
 * tokens de identidade. Ele não importa React, backend nem domínio de viagens —
 * é isso que permite que e-mail, manifest, ícone e um consumidor fora deste
 * repositório dependam dele sem arrastar a árvore de componentes.
 *
 * `packages/ui` é consumidor, não dono. A regra de fonte única do ADR-0022
 * continua valendo; o que mudou foi de quem ela é.
 */

export const platformBrand = {
  /** Nome público completo. Vai a título, wordmark, assunto de e-mail. */
  name: 'Destraflow Tech',
  /** Forma curta para onde o espaço é do sistema operacional (PWA, aba). */
  shortName: 'Destraflow',
  /** Site institucional. Canônico do projeto da landing, sem `www`. */
  siteUrl: 'https://destraflow.com.br',
  /** Onde o time entra. É o CRM, em subdomínio próprio. */
  loginUrl: 'https://crm.destraflow.com.br/login',
} as const;

export type PlatformBrand = typeof platformBrand;

/*
 * A geometria do símbolo D, em viewBox 0 0 48 48 e `fill-rule="evenodd"`.
 *
 * Mora aqui, e não só em `assets/symbol.svg`, porque o CRM precisa dela como
 * SVG inline — para herdar `currentColor` e o tamanho do contexto — e uma
 * segunda cópia escrita à mão seria exatamente a cópia sem guarda que o
 * ADR-0098 proíbe. `tokens.test.ts` confere que o arquivo e esta constante
 * dizem a mesma coisa.
 */
export const symbolPath =
  'M5.5 5h18c10.493 0 19 8.507 19 19s-8.507 19-19 19h-18V5zm8 10v18h10c4.97 0 9-4.03 9-9s-4.03-9-9-9h-10zm5 4 9.5 5-9.5 5V19z';

export const symbolViewBox = '0 0 48 48';

export { lightPalette } from './tokens';
export type { LightPalette } from './tokens';
