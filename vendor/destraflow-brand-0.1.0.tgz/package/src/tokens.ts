/*
 * Paleta do tema claro para superfícies que NÃO carregam tokens.css: hoje, o
 * e-mail transacional (clients de e-mail não resolvem CSS do app).
 *
 * Espelha o bloco claro de tokens.css; `tokens.test.ts` trava a deriva entre os
 * dois, campo a campo. Cópia de cor sem guarda é proibida pelo ADR-0098 — é a
 * forma mais comum de a marca ficar velha em um lugar só.
 */
export const lightPalette = {
  background: '#f7f7f4',
  surface: '#ffffff',
  surfaceRaised: '#efeee8',
  border: '#e2e1da',
  text: '#26251e',
  textMuted: '#5a5852',
  primary: '#26251e',
  primarySubtle: '#e8e7e0',
  primaryForeground: '#ffffff',
  brandGold: '#7d6024',
  brandSignature: '#c7a06b',
  brandSignatureForeground: '#14100b',
} as const;

export type LightPalette = typeof lightPalette;
